Readme File
2017/04/09-13:16:12
This package contains HyperSQL v. 2.4.0

HyperSQL Database is a relational database management system and a set of tools
written in Java.
HyperSQL is also known as HSQLDB.

The file "index.html" explains the contents of this distribution and has
links to documentation and support resources.
